-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2019 at 07:22 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `icecream`
--
CREATE DATABASE IF NOT EXISTS `icecream` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `icecream`;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `ID` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `ice_id` int(11) NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`ID`, `uid`, `ice_id`, `active`) VALUES
(23, 1, 0, 1),
(27, 1, 91, 1);

-- --------------------------------------------------------

--
-- Table structure for table `icecreams`
--

CREATE TABLE `icecreams` (
  `ID` int(11) NOT NULL,
  `icecreamname` varchar(150) NOT NULL,
  `price` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `active` varchar(1) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `icecreams`
--

INSERT INTO `icecreams` (`ID`, `icecreamname`, `price`, `discount`, `tid`, `cid`, `active`, `image`) VALUES
(86, 'Rasberry', 250, 0, 1, 1, '1', 'rasberry1.jpg'),
(87, 'Black Rasberry', 350, 0, 1, 1, '1', 'blackrasberry.jpg'),
(88, 'Chocolate Rasberry', 400, 0, 1, 1, '1', 'chocorasberry.jpg'),
(89, 'Black Rasberry Chocolate', 450, 0, 1, 1, '1', 'blackrasberrychoco.jpg'),
(90, 'Cheats Rasbrry', 300, 0, 1, 1, '1', 'cheatsrasberry.jpg'),
(91, 'Paleo Rasberry', 250, 0, 1, 1, '1', 'paleorasberry.jpg'),
(92, 'Ginger Rasberry Swirl', 450, 0, 1, 1, '1', 'gingerrasberryswirl.jpg'),
(93, 'Coconut Mint  chip', 340, 0, 1, 1, '1', 'coconutmintchip.jpg'),
(94, 'Espresso Chocolate Chip', 400, 0, 1, 1, '1', 'espressochocochip.jpg'),
(95, 'Double Chocolate Chip', 500, 0, 1, 1, '1', 'doublechocolatechip.jpg'),
(96, 'Lavender Dark Chip', 350, 0, 1, 1, '1', 'lavenderdarkchip.jpg'),
(97, 'Mint Chocolate Chip', 450, 0, 1, 1, '1', 'mint_chocolatechip.jpg'),
(98, 'Chocolate Chip', 250, 0, 1, 1, '1', 'chocolatechip.jpg'),
(99, 'Coconut Cripsy', 250, 0, 1, 1, '1', 'coconut icecream cripsy.jpg'),
(100, 'Coffee Coconut', 300, 0, 1, 1, '1', 'coffeecoconut.jpg'),
(101, 'Sweet Corn Coconut', 350, 0, 1, 1, '1', 'sweetcorncoconut.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `icecream_company`
--

CREATE TABLE `icecream_company` (
  `ID` int(11) NOT NULL,
  `company` varchar(150) NOT NULL,
  `active` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `icecream_company`
--

INSERT INTO `icecream_company` (`ID`, `company`, `active`) VALUES
(1, 'robby', '1'),
(2, 'sss', '1');

-- --------------------------------------------------------

--
-- Table structure for table `icecream_order`
--

CREATE TABLE `icecream_order` (
  `ID` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `ice_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `icecream_order`
--

INSERT INTO `icecream_order` (`ID`, `uid`, `ice_id`, `quantity`, `active`) VALUES
(13, 1, 88, 1, 1),
(14, 1, 88, 1, 1),
(15, 1, 88, 1, 1),
(16, 1, 88, 1, 1),
(17, 1, 88, 1, 1),
(18, 1, 88, 1, 1),
(19, 1, 88, 1, 1),
(20, 1, 88, 1, 1),
(21, 1, 89, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `ID` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `review` varchar(500) NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`ID`, `uid`, `review`, `active`) VALUES
(1, 1, 'This is nyc to spend tym', 1);

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE `types` (
  `ID` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `active` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`ID`, `name`, `active`) VALUES
(1, 'Rasberry', '1'),
(3, 'Rasberr', '1'),
(4, 'Chocolate chip', '1'),
(5, 'Coconut', '1');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `profile` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `pwd` varchar(250) NOT NULL,
  `phno` varchar(12) NOT NULL,
  `address` varchar(500) NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `name`, `profile`, `email`, `pwd`, `phno`, `address`, `active`) VALUES
(1, 'yashwin', 'yo.jpeg', 'yash@gmail.com', '1234', '8310156617', 'site no.250', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ice_id` (`ice_id`),
  ADD KEY `cart_ibfk_1` (`uid`);

--
-- Indexes for table `icecreams`
--
ALTER TABLE `icecreams`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `icecreams_ibfk_1` (`cid`),
  ADD KEY `tid` (`tid`);

--
-- Indexes for table `icecream_company`
--
ALTER TABLE `icecream_company`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `icecream_order`
--
ALTER TABLE `icecream_order`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `icecreams`
--
ALTER TABLE `icecreams`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `icecream_company`
--
ALTER TABLE `icecream_company`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `icecream_order`
--
ALTER TABLE `icecream_order`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `types`
--
ALTER TABLE `types`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `icecreams`
--
ALTER TABLE `icecreams`
  ADD CONSTRAINT `icecreams_ibfk_1` FOREIGN KEY (`tid`) REFERENCES `types` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
