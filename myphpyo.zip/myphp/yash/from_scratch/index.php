<?php
$visible=true;
session_start();
if (isset($_SESSION['login'])){
    $visible=false;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="../include/css/bootstrap.min.css">
    <link rel="stylesheet" href="../include/css/css/all.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script type="text/javascript" src="../include/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <style>
        *{
            margin: 0;
            padding: 0;
            font-family: sans-serif;
        }
        .card{
            border: none;
            border-radius: 5px;
            -webkit-box-shadow: 6px 5px 21px 6px rgba(0,0,0,0.75);
            -moz-box-shadow: 6px 5px 21px 6px rgba(0,0,0,0.75);
            box-shadow: 6px 5px 21px 6px rgba(0,0,0,0.75);
            margin-bottom: 100px;
        }
        .card-title,.card-text{
            text-align: center;
        }

        .navigation{
            width: 100%;
            background-color: #333333;
            color: white;
            box-sizing: border-box;
            position: fixed;
            z-index: 100;
            top: 0;
            left: 0;
        }

        .logo{
            float: left;
            line-height: 50px;
            height: 50px;
            font-size: 30px;
        }
        nav{
            float: right;
        }
        nav ul{
            display: flex;
            margin: 0;
            padding: 0;
            height: 50px;
            line-height: 50px;
        }
        nav ul li{
            list-style-type: none;
        }
        .container-fluid nav ul li a{
            text-decoration: none;
            padding: 0 30px;
            color: white;
            display: block;
        }
        nav ul li a i{
            margin-right: 7px;
        }
        .container-fluid nav ul li a:hover,.container-fluid nav ul li.active{
            background-color: #31b0d5;
            transition: .5s;
        }
        .sliding{
            margin-top: 80px;
        }
        .menu-toggle{
            font-size: 30px;
            line-height: 50px;
            float: right;
            display: none;
            cursor: pointer;
        }
        @media (max-width: 900px) {
            nav{
                top: 50px;
                position: absolute;
                height: 100vh;
                width: 50%;
                background-color: #333333;
                left: -50%;
                transition: 1.5s;
            }
            .navigation nav.active{
                left: 0;
            }
            nav ul {
                display: block;
            }
            nav ul li a{
                text-align: center;
                display: block;
            }
            .menu-toggle{
                display: block;
            }
        }
        .login{
            position: fixed;
            background-color: #ffffff;
            left: 50%;
            top: -100%;
            transform: translate(-50%,-50%);
            z-index: 20;
            box-shadow: #333333;
        }
         .login button{
             width: 100%;
         }
         .login h1{
             text-align: center;
             margin-top: 0;
         }
         .login{
             padding: 20px;
             border-radius: 10px;
             width: 350px;
             margin-top: 100px;
             box-shadow: 4px 2px 10px #0b2e13 ;
         }
        .overlay{
            width: 100%;
            z-index: 20;
            top: 0;
            height: 0;
            background-color: rgba(0,0,0,.5);
            position: fixed;
        }
        #login-close,#reg-close{
            cursor: pointer;
            padding: 7px;
            font-size: 15px;
            position: absolute;
            right: 10px;
            top: 10px;
        }
        .register{
            position: fixed;
            background-color: #ffffff;
            top: -100%;
            left: 50%;
            z-index: 30;
            border-radius: 10px;
            height: auto;
            box-shadow: 4px 2px 10px #0b2e13 ;
            width: 350px;
            transform: translate(-50%,-50%);
            box-shadow: #333333;
        }
        .register form div:nth-child(3){
            height: 60px;
            width: 60px;
            margin: auto;
            border-radius: 50%;
            background-color: #1b1e21;
        }
        .register img{
            height: 100%;
            width: 100%;
            border-radius: 50%;
        }
        .register button{
            width: 100%;
        }
        .login span{
            position: absolute;
            right: 10%;
            bottom: 2%;
            text-align: center;
        }
        .login span a#register{
            cursor: pointer;
            color: #31b0d5;
        }
        .register h1{
            text-align: center;
        }
        .register .form-group input{
            border: none;
            box-shadow: none;
        }
        .register .form-group textarea{
            resize: none;
        }
        .register .form-group textarea:focus{
            box-shadow: none;
            outline: none;
        }
        .register hr{
            margin-top: 0;
        }
        .register .form-group input:focus + hr{
            background-color: #31b0d5;
        }
         .icecream-display{
             margin-top: 100px;
         }
    </style>
    <script>
        function order_now(ele) {
            var item=ele.parentElement.parentElement.id;
            $.ajax({
                url: "order_cart.php",
                method: "post",
                dataType: 'text',
                success:function (response) {
                    if (response=='login')
                        $('#login').click();
                    else
                        window.location.href="order_page.php?id="+item+"";
                }
            })
        }
        function add_to_cart(ele) {
            var item=ele.parentElement.parentElement.id;
            $.ajax({
                url: "order_cart.php",
                method: "post",
                dataType: 'text',
                data : {
                    'item' : item,
                },
                success : function (response) {
                    if (response=="success")
                        alert("Item added successfully to the cart");
                    else if (response=='exist')
                        alert("Item already added to the cart");
                    else if (response=='login'){
                        $('#login').click();
                    }
                }
            })
        }
        $('#btn').bind('click',function () {
            $('.inner-wrapper').animate({left:"0%"},3000);
        })

    </script>
</head>
<body>
<div class="container-fluid navigation">
    <div class="logo">LOGO</div>
    <nav>
        <ul>
            <li class="active nav-li"><a href="#" ><i class="fas fa-home"></i>Home</a></li>
            <li class="nav-li"><a href="about.html"><i class="fas fa-ice-cream"></i>About</a></li>
            <li id="cart" class="nav-li"><a href="#"><i class="fas fa-cart-plus"></i>My Cart</a></li>
            <?php if ($visible){ ?>
            <li class="nav-li" id="login"><a href="#"><i class="fas fa-sign-in-alt"></i>Login</a></li>
            <?php } ?>
            <?php if (!$visible) { ?>
            <li class="nav-li" id="logout"><a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a></li>
            <?php } ?>
        </ul>
    </nav>
    <div class="menu-toggle"><i class="fas fa-bars" aria-hidden="true"></i></div>
</div>

<div class="overlay"></div>

<div class="container-fluid login">
    <form action="#" method="post">
        <i id="login-close" class="fas fa-times"></i>
        <h1>LOGIN</h1>
        <div class="form-group">
            <label for="login-email">Email</label>
            <input type="text" class="form-control" placeholder="Enter your Email" id="login-email" name="email">
        </div>
        <div class="form-group">
            <label for="login-pwd">Password</label>
            <input type="password" class="form-control" placeholder="Enter your Password" id="login-pwd" name="pwd">
        </div>
        <button id="login-submit" class="btn btn-primary" type="submit">SUBMIT</button>
        <br><br>
        <span>New User?  <a id="register">Register</a></span>
    </form>
</div>

<div class="container-fluid mt-5 register">
    <form action="#" enctype="multipart/form-data" method="post">
        <i id="reg-close" class="fas fa-times"></i>
        <h1>REGISTER</h1>
        <div class="form-group">
            <input type="file" class="form-control" hidden="hidden" id="reg-profile" name="reg-profile">
            <img id="profile" src="../default_images/profile2.png" alt="Profile">
            <br>
        </div>

        <div class="form-group">
            <input type="text" class="form-control" placeholder="Name" id="reg-name" name="reg-name">
            <hr>
        </div>

        <div class="form-group">
            <input type="tel" pattern="[0-9]{12}" class="form-control" placeholder="Phone" id="reg-phno" name="reg-phno">
            <hr>
        </div>

        <div class="form-group">
            <input type="text" class="form-control" placeholder="Email" id="reg-email" name="reg-email">
            <hr>
        </div>

        <div class="form-group">
            <input type="password" class="form-control" placeholder="Password" id="reg-pwd" name="reg-pwd">
            <hr>
        </div>

        <div class="form-group">
            <input type="password" class="form-control" placeholder="Confirm Password" id="con-pwd" name="reg-pwd">
            <hr>
        </div>

        <div class="form-group">
            <textarea rows="2" class="form-control" placeholder="Address" id="reg-address" name="reg-address"></textarea>
            <hr>
        </div>

        <button class="btn btn-primary" id="reg-submit" type="submit">SUBMIT</button>
        <br>
        <br>
    </form>
</div>

<div class="container-fluid sliding">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="item active">
                <img src="ice/icecream2.jpg" alt="Los Angeles"  style="width:100%;height: 80vh">
                <div class="carousel-caption" style="margin-bottom: 100px">
                    <h1 style="font-size: 5vw;color: #0b2e13;text-shadow: 1px 1px 1px white">ICECREAM CITY</h1>
                    <h2 style="color: #0b2e13">City of Tasty Icecreams</h2>
                </div>
            </div>

            <div class="item">
                <img src="ice/icecream3.jpg" alt="Chicago" style="width:100%;height: 80vh">
                <div class="carousel-caption">
                    <h1>We have the best of icecreams</h1>
                </div>
            </div>

            <div class="item">
                <img src="ice/icecream1.jpg" alt="New york" style="width:100%;height: 80vh">
            </div>
        </div>
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>

<div class="container icecream-display">
    <?php
            include_once "sql.php";
            $type=mysqli_query($sql,"select * from types");
            while ($head=mysqli_fetch_assoc($type)) {
                ?>
                <div class="main-container">
                <div class="row mt-5">
                    <?php
                    if ($sql) {
                        $res = mysqli_query($sql, "select * from icecreams where tid= $head[ID] and active=1");
                        if ($res) {
                            while ($row = mysqli_fetch_assoc($res)) {
                                ?>
                                <div class="col-md-3">
                                    <div class="card" id="<?php echo $row['ID'] ?>">
                                        <img class="card-img-top" src="ice/<?php echo $row['image']; ?>" height="150px">
                                        <div class="card-title mt-2 mb-0">
                                            <h4><?php echo $row['icecreamname']; ?></h4>
                                        </div>
                                        <div class="card-text">
                                            <h1><i class="fas fa-rupee-sign"></i> <?php echo $row['price']; ?></h1>
                                            <button onclick="order_now(this)" class="btn btn-success text-light">Buy
                                                Now
                                            </button>&nbsp;
                                            <button onclick="add_to_cart(this)" class="btn btn-danger text-light">Add to
                                                cart
                                            </button>
                                            <br/><br/>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                        }
                    }
                    ?>
                </div>
                <?php
            }
    ?>
</div>
</div>

<div class="container ml-3">
    <div class="row mb-2">
        <h4>Ratings and Reviews</h4>
    </div>
    <?php
        include_once "sql.php";
        if ($sql){
            $res=mysqli_query($sql,"select u.name,u.profile,r.review from user u,reviews r where u.ID=r.uid and u.active=1");
            if ($res){
                while ($row=mysqli_fetch_assoc($res)){ ?>
                    <div class="row mb-5">
                        <div class="media">
                            <img src="uploads/yo.jpeg"  style="height: 100px;width: 100px " class="mr-3" alt="...">
                            <div class="media-body">
                                <h6 class="mt-0"><?php echo $row['name'] ?></h6>
                                <?php echo $row['review'] ?>
                            </div>
                        </div>
                    </div>
                <?php
                }
            }
        } ?>
</div>

<div class="container ml-3">
    <div class="row mb-2">
        <h4>Post Your Reviews</h4>
    </div>
    <form>
        <div class="form-group">
            <label for="comment">Comments</label>
            <textarea style="resize: none" type="text" class="form-control" id="comment" placeholder="Write your own reviews" rows="3"></textarea>
        </div>
        <button class="btn btn-primary">Submit</button>
    </form>
    <br/><br/>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        $('.menu-toggle').bind('click',function () {
            $('nav').toggleClass('active');
        })
        $('.nav-li').bind('click',function () {
            $(this).siblings().removeClass('active');
            $(this).addClass('active');
        })
        $('#login').bind('click',function () {
            $('.login').animate({top:"40%"},1000);
            $('.overlay').animate({height:"100vh"});
            $('nav').removeClass('active');
        })
        $('#login-close').bind('click',function () {
            $('.overlay').animate({height:"0"},1000);
            $('.login').animate({top:"-100%"});
        })
        $('#login-submit').bind('click',function () {
            var email=$('#login-email').val();
            var pwd=$('#login-pwd').val();
            if (email==''||pwd=='')
                alert('Please Check Your Inputs');
            else {
                $.ajax({
                    url : "login.php",
                    method:"post",
                    data:{
                        'email':email,
                        'pwd': pwd
                    },
                    dataType:'text',
                    success : function (response) {
                        if (response) {
                            alert('Login Successful');
                            $('.login').animate({top:"-100%"});
                            $('.overlay').animate({height:"0"},1000);
                        }
                        else
                            alert('Login Failed');
                    }
                })
            }
        })
        $('#register').bind('click',function () {
            $('.register').animate({top:"49%"},1000)
        })
        $('#reg-close').bind('click',function () {
            $('.register').animate({top:"-100%"},1000);
        })
        $('#profile').bind('click',function () {
            $('#reg-profile').click();
        })
        $('#reg-submit').bind('click',function () {
            var name=$('#reg-name').val();
            var phno=$('#reg-phno').val();
            var email=$('#reg-email').val();
            var pwd=$('#reg-pwd').val();
            var profile=$('#reg-profile')[0].files[0];
            var fd=new FormData();
            fd.append('file',profile);
            var con_pwd=$('#con-pwd').val();
            var addr=$('#address').val();
            $.ajax({
                url:"example.php",
                method:"post",
                dataType:"text",
                contentType:false,
                processData:false,
                data :{
                    'name':name,
                    'phno':phno,
                    'email':email,
                    'pwd':pwd,
                    'file':fd,
                    'addr':addr,
                },
                success:function (response) {
                    alert(response);
                }
            })
        })
        $('#reg-profile').change(function (event) {
            if (event) {
                $('#profile').attr('src',URL.createObjectURL(event.target.files[0]));
            }
        })
        $('#cart').bind('click',function () {
            $.ajax({
                url: "logged_in.php",
                method: "post",
                dataType: 'text',
                success:function (response) {
                    if (response=='0')
                        $('#login').click();
                    else
                        window.location.href="cart.php";
                }
            })
        })
    })
</script>
</body>
</html>
