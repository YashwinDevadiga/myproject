<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Page</title>
    <style>
        form{
            margin-top: 15%;
            margin-left: 30%;
            width: 100%;
        }
        form input,select{
            width: 25%;
            padding: 5px;
        }
        form input,select{
            margin-top: 10px;
            margin-left: 100px;
        }
        form label{
            position: absolute;
            margin-top: 10px;
        }
    </style>
<body>
<form action="actions.php" method="post" enctype="multipart/form-data">
    <table>
        <label>Name</label>
        <input type="text" name="name" required><br>
        <label>Type</label>
        <input list="search" name="type" autocomplete="off" required>
        <datalist id="search">
            <?php
            include_once "sql.php";
            $row=mysqli_query($sql,"select name from types");
            while ($arr=mysqli_fetch_assoc($row)) { ?>
            <option value="<?php echo $arr['name'] ?>">
                <?php } ?>
        </datalist>
        <br>
        <label>Price</label>
        <input type="number" min="0" name="price" required><br>
        <label>Image</label>
        <input type="file" name="image" required><br>
        <input type="submit" name="submit" value="submit">
</form>
</body>
</html>
