<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../include/bootstrap.min.css">
    <title>Document</title>
    <style>
        .container .col-sm-4 label {
            margin-bottom: 3vw;
        }
        .container{
            height: 40vh;
        }
        .container img{
            height: 100%;
        }
    </style
</head>
<body>
    <div class="container">
        <img src="ice/icecream1.jpg" alt="img" class="img-responsive col-sm-4" style="border-radius: 50px;margin-top: auto;row-span: 4" >
        <div class="col-sm-4">
            <label>Name</label><br>
            <label>Delivery Charge</label> <br>
            <label>Quantity</label> <br>
            <input type="text" min="0">
        </div>
        <div class="col-sm-4">
            <label>Price</label><br>
            <label>Total</label> <br>
            <button type="button" min="0" class="btn btn-block">Order Now</button>
        </div>
    </div>
</body>
</html>