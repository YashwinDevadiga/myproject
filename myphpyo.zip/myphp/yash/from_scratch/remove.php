<?php
    include_once "sql.php";
    $id=$_POST['id'];
    exit($res=mysqli_query($sql,"delete from cart where ID='$id'"));
    if ($res){
        exit('1');
    }
?>