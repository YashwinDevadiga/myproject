<?php
    include_once "sql.php";
    $item=$_POST['item'];
    session_start();
    if (isset($_SESSION['login'])) {
        $uid=$_SESSION['login'];
        if ($sql) {
                $res = mysqli_query($sql, "select * from cart where uid='$uid' and ice_id='$item' and active=1");
                if (mysqli_num_rows($res) == 0) {
                    $res = mysqli_query($sql, "insert into cart values(0,'$uid','$item',1)");
                    if ($res)
                        exit("success");
                } else
                    exit("exist");
        }
        else
            exit("Oops!...Something went wrong");
    }
    else{
        exit('login');
    }
?>
