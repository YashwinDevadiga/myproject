<?php
    $name=$_POST['name'];
    $phno=$_POST['phno'];
    $addr=$_POST['addr'];
    include_once "sql.php";
    session_start();
    $id=$_SESSION['login'];
    $res=mysqli_query($sql,"update user set name='$name',phno='$phno',address='$addr' where ID='$id'");
    if ($res){
        exit('1');
    }
?>