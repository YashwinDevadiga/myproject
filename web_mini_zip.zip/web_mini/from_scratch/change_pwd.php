<?php
    session_start();
    $id=$_SESSION['login'];
    $pwd=$_POST['pwd'];
    $c_pwd=$_POST['c_pwd'];
    include_once "sql.php";
    $res=mysqli_query($sql,"select * from user where ID='$id' and pwd='$c_pwd'");
    if(mysqli_num_rows($res)==0){
        exit('0');
    }
    else {
        $res = mysqli_query($sql, "update user set pwd='$pwd' where ID='$id'");
        if ($res)
            exit('1');
    }
    ?>