<?php
    $id=$_POST['id'];
    $item=$_POST['item'];
    session_start();
    $uid=$_SESSION['login'];
    include_once "sql.php";
    $res=mysqli_query($sql,"insert into icecream_order values(0,'$uid','$id','$item',1)");
    if ($res)
        exit('1');
    else
        exit('0');
?>
