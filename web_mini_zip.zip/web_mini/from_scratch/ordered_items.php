<?php
    session_start();
    $id=$_SESSION['login'];
    include_once "sql.php";
    $res=mysqli_query($sql,"select o.ID,i.icecreamname,i.price,i.image,o.quantity from icecream_order o,icecreams i,user u where u.ID=o.uid and o.ice_id=i.ID and i.ID and u.ID='$id'");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="../include/css/css/all.css">
    <style>
        .container{
            width: 40%;
            float: left;
            display: flex;
            margin-left: 5%;
            margin-top: 2%;
            box-shadow: 1px 1px 10px 1px black;
        }
        img{
            width: 100%;
            height: 300px;
            padding: 5px;
        }
        .container .image{
            width: 50%;
            height: 100%;
        }
        .container .details{
            width: 40%;
            margin-left: 10%;
            margin-top: 25%;
        }
        button{
            padding: 5px 20px;
            border: none;
            box-shadow: 1px 1px 5px 1px black;
        }
    </style>
    <script src="../include/jquery.min.js"></script>
</head>
<body>
    <?php
        if (mysqli_num_rows($res)==0){
            echo "<h1 style='text-align: center;margin-top: 20%;color: silver'><i class='fas fa-surprise'></i>  Nothing is Ordered yet...!</h1>";
        }
        else {
            ?>
            <h1 style="text-align: center">Ordered Items</h1>
            <?php
            while ($row = mysqli_fetch_assoc($res)) {
                ?>
                <div class="container">
                    <div class="image">
                        <img src="ice/<?php echo $row['image']; ?>" alt="">
                    </div>
                    <div class="details">
                        <h4><?php echo $row['icecreamname']; ?></h4>
                        <h4>Price: <i class="fas fa-rupee-sign"> <?php echo $row['price']; ?></i></h4>
                        <h4>Quantity: <?php echo $row['quantity']; ?></h4>
                        <button class="cancel" id="<?php echo $row['ID']; ?>">Cancel</button>
                    </div>
                </div>
                <?php
            }
        }
    ?>
    <script>
        $(document).ready(function () {
            $('.cancel').bind('click',function () {
                var id=this.id;
                $.ajax({
                    url:"cancel.php",
                    method:"post",
                    data:{
                        'id':id
                    },
                    success:function (response) {
                        if (response){
                            alert('Order Canceled');
                            window.location.reload();
                        }
                    }
                })
            })
        })
    </script>
</body>
</html>
