<?php
    session_start();
    if (!isset($_SESSION['login'])){

    }
    else {
        $id = $_SESSION['login'];
        $ice_id=$_GET['id'];
        include_once "sql.php";
        $res=mysqli_query($sql,"select * from icecreams where ID='$ice_id'");
        $row=mysqli_fetch_assoc($res);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../include/css/css/all.css">
    <style>
        button{
            width: 80%;
            padding: 5px;
            background-color: whitesmoke;
            border: none;
            box-shadow: 0px 0px 5px 0px #000000;
        }
        .container{
            width: 60%;
            margin: 10% 20%;
            box-shadow: 0px 0px 10px #000000;
            overflow: auto;
        }
        .details{
            margin-top: 5%;
            float: left;
            width: 20%;
        }
        .image{
            width: 40%;
            height: 200px;
            margin: 5%;
            float: left;
        }
        .image img {
            width: 100%;
            height: 100%;
        }
        #thank{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            display: none;
        }
        #thank h1{
            color: #707070;
            display: inline;
        }
        #thank i{
            color: #707070;
            font-size: 40px;
        }
    </style>
</head>
<body>
    <h1 style="text-align: center">Order Page</h1>
    <div class="container" id="<?php echo $row['ID'];?>">
        <div class="image">
            <img src="ice/<?php echo $row['image']; ?>" alt="">
        </div>
        <div class="details">
            <h3><?php echo $row['icecreamname']; ?></h3>
            <h3><?php echo $row['price']; ?></h3>
            <h3>Quantity <input id="item" type="number" min="1" value="1"></h3>
            <button id="btn">Order Now</button>
        </div>
    </div>
    <div  id="thank">
        <i class="fas fa-smile-beam"></i>
        <h1>Thank you for ordering....!</h1>
    </div>
    <script src="../include/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#btn').bind('click',function () {
                var id=this.parentElement.parentElement.id;
                var item=$('#item').val();
                $.ajax({
                    url:"order.php",
                    method:"post",
                    data:{
                        'id':id,
                        'item':item,
                    },
                    success:function (response) {
                        if (response=='1') {
                            alert("Item ordered successfully");
                            $('#thank').show();
                            $('#'+id).hide();
                        }
                    }
                })
            })
        })
    </script>
</body>
</html>
<?php } ?>