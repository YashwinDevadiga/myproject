<?php
    $id=$_POST['id'];
    include_once "sql.php";
    $res=mysqli_query($sql,"delete from icecream_order where ID='$id'");
    exit($res);
?>