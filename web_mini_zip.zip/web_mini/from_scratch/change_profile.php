<?php
    $file=$_FILES['file']['name'];
    $tmp=$_FILES['file']['tmp_name'];
    move_uploaded_file($tmp,'uploads/'.$file);
    include_once "sql.php";
    session_start();
    $id=$_SESSION['login'];
    $res=mysqli_query($sql,"update user set profile='$file' where ID='$id'");
    if ($res)
        exit('1');
?>
