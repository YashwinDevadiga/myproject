<?php
include_once "sql.php";
    $email = $_POST['email'];
    $password = $_POST['pwd'];
    $res=mysqli_query($sql,"select * from user where email='$email'and pwd='$password'");
    if (mysqli_num_rows($res)==0){
       exit('0');
    }
    else{
        $row=mysqli_fetch_assoc($res);
        session_start();
        $_SESSION['login']=$row['ID'];
        exit($_SESSION['login']);
    }
?>