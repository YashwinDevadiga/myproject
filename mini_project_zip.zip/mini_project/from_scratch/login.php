<?php
    $email=$_POST['email'];
    $pwd=$_POST['pwd'];
    include_once "sql.php";
    if ($sql){
        if ($res=mysqli_query($sql,"select * from user where email='$email' and pwd='$pwd'")){
            if (mysqli_num_rows($res)>0) {
                $row = mysqli_fetch_assoc($res);
                session_start();
                $_SESSION['login']=$row['ID'];
                exit($_SESSION['login']);
            }
            else
                exit(0);
        }
        else {
            exit(0);
        }
    }
?>