<?php
include "sql.php";
    $name = $_POST['name'];
    $price = $_POST['price'];
    $discount = $_POST['discount'];
    $type = $_POST['type'];
    $image = $_FILES['image']['tmp_name'];
    $row = mysqli_query($sql, "select * from types where name ='$type'");
    if (mysqli_num_rows($row) == 0)
           mysqli_query($sql,"insert into types values(0,'$type',1)");
        $res = mysqli_query($sql, "select ID from types where name ='$type'");
    $row = mysqli_fetch_assoc($res);
    $tid = $row['ID'];
    $newfile=$_FILES['image']['name'];
    mysqli_query($sql,"insert into icecreams values(0,'$name','$price','$discount',1,1,1,'$newfile')");
    move_uploaded_file($image,'ice/'.$newfile);

header("Location: admin.php");
?>
