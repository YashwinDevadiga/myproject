<?php
    $name=$_POST['name'];
    $phno=$_POST['phno'];
    $email=$_POST['email'];
    $pwd=$_POST['pwd'];
    $addr=$_POST['addr'];
    include_once "sql.php";
    $res=mysqli_query($sql,"insert into user values(0,'$name','','$email','$pwd','$phno','$addr',1)");
    if ($res){
       exit('1');
    }
    ?>
