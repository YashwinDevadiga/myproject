<?php
    include_once "sql.php";
    $res=mysqli_query($sql,"select u.name as uname,i.icecreamname as iname,o.quantity,i.price from user u,icecream_order o,icecreams i where u.ID=o.uid and i.ID=o.ice_id order by o.ID desc");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        h1{
            text-align: center;
        }
        table{
            width: 80%;
            margin: 5% 10%;
            border-collapse: collapse;
        }
        td{
            text-align: center;
        }
        td{
            padding: 10px 20px;
            border: 1px solid black;
        }
        th{
            padding: 15px 20px;
            border: 1px solid black;
            font-size: 1.5vw;
        }
    </style>
</head>
<body>
    <h1>Order Details</h1>
    <table>
        <tr>
            <th>Name</th>
            <th>Icecream</th>
            <th>Quantity</th>
            <th>Price/Icecream</th>
            <th>Total</th>
        </tr>
        <?php
        while ($row=mysqli_fetch_assoc($res)){?>
        <tr>
            <td><?php echo $row['uname']; ?></td>
            <td><?php echo $row['iname']; ?></td>
            <td><?php echo $row['price']; ?></td>
            <td><?php echo $row['quantity']; ?></td>
            <td><?php echo $row['quantity']*$row['price']; ?></td>
        </tr>
        <?php }
        ?>
    </table>
</body>
</html>
