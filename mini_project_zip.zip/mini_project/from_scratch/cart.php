<?php session_start();
if (!isset($_SESSION['login'])) {
    header('location:index.php');
}
else{
    $uid=$_SESSION['login']; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cart</title>
    <link rel="stylesheet" href="../include/bootstrap.css">
    <link rel="stylesheet" href="../include/css/css/all.css">
    <style>
        *{
            padding: 0;
            margin: 0;
        }
        .each-item{
            width: 40%;
            margin: 50px 5%;
            padding: 10px;
            box-shadow: 1px 1px 10px #2E7D32;
            overflow: auto;
            float: left;
        }
        .each-item img{
            width: 100%;
            height: 200px;
        }
        .each-item div{
            float: left;
        }
        table{
            width: 80%;
            margin-left: 10%;
            text-align: center;
        }
        table,tr,td{
            border: 1px solid black;
        }
        td,th{
            padding: 10px;
        }
        button{
            width: 90px;
            text-align: center;
            padding-top: 2px;
        }
        .btn-grp{
            position: absolute;
            bottom: 10px;
        }
        .each-item{
            position: relative;
        }
    </style>
    <script src="../include/jquery.min.js"></script>
    <script>
        function order_now(ele){
            var id=ele.parentElement.parentElement.parentElement.id;
            window.location.href="order_page.php?id="+id+"";
        }
        function remove(id) {
            $.ajax({
                url:"remove.php",
                method: "post",
                dataType:"text",
                data:{
                    'id':id,
                },
                success:function (response) {
                    if (response=="1") {
                        alert("Removed successfully");
                        window.location.reload();
                    }
                }
            })
        }
    </script>
</head>
<body>
    <?php
    include_once "sql.php";
    $res = mysqli_query($sql,"select i.icecreamname,i.price,i.ID,c.ID as id,i.image from icecreams i,cart c,user u where c.ice_id=i.ID and u.ID=c.uid and u.ID='$uid' and c.active=1");
    if (mysqli_num_rows($res)==0){
    echo "<h1 style='text-align: center;margin-top: 20%;color: silver'><i class='fas fa-sad-tear'></i>  No Items in the Cart</h1>";
    }
    else {
        ?>
    <h1 style="text-align: center">MY CART</h1>
    <div class="items">
        <?php
        while ($row = mysqli_fetch_assoc($res)) {
            ?>
            <div class="each-item" id="<?php echo $row['ID']; ?>">
                <div style="width: 50%">
                    <h6 style="margin-top: 100px"><?php echo $row['icecreamname']; ?></h6>
                    <h5><?php echo $row['price']; ?></h5>
                    <div class="btn-grp">
                        <button onclick="order_now(this)">Order Now</button>
                        <button onclick="remove(<?php echo $row['id']; ?>)">Remove</button>
                    </div>
                </div>
                <div style="width: 50%">
                    <img src="ice/<?php echo $row['image']; ?>" alt="">
                </div>
            </div>
            <?php
        }
    } ?>
</div>
<br><br><br><br>
</body>
</html>
<?php } ?>