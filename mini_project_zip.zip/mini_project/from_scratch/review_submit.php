<?php
    session_start();
    $review=$_POST['review'];
    $uid=$_SESSION['login'];
    include_once "sql.php";
    $res=mysqli_query($sql,"insert into reviews values (0,'$uid','$review',1)");
    if ($res)
        exit('1');
?>