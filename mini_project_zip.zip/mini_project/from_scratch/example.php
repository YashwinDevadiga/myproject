<?php
    exit($file=$_POST['name']);
    exit($name=$_FILES[$file]['name']);
    $tmp_name=$_FILES['file']['tmp_name'];
    exit(move_uploaded_file($tmp_name,'uploads/'.$name));
    ?>