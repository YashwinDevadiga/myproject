<?php
    session_start();
    if (isset($_SESSION['login']))
        exit('1');
    else
        exit('0');
?>
