<?php
    $file=$_FILES['file']['name'];
    $tmp=$_FILES['file']['tmp_name'];
    move_uploaded_file($tmp,'uploads/'.$file);
    include_once "sql.php";
    $res=mysqli_query($sql,"select ID from user order by ID desc");
    $id=mysqli_fetch_assoc($res)['ID'];
    $res=mysqli_query($sql,"update user set profile='$file' where ID='$id'");
    if ($res)
        exit('1');
?>